# Half Adder – Verilog

This project implements a simple Half Adder using Verilog.

## Files
- `half_adder.v`: RTL code
- `tb_half_adder.v`: Testbench

## How to Simulate

Using Xilinx ISE or any Verilog simulator like Xcelium:

```
xrun half_adder.v tb_half_adder.v
```

## Expected Output:
```
A B | SUM CARRY
0 0 |  0    0
0 1 |  1    0
1 0 |  1    0
1 1 |  0    1
```
